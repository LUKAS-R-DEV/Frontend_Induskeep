<script>
  // Layout vazio só para o login
  // Não importa sidebar nem navbar
</script>

<slot />

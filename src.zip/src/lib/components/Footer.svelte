<footer class="footer">
  <p>© 2025 INDUSKEEP - Todos os direitos reservados</p>
</footer>

<style>
  .footer {
    text-align: center;
    padding: 1rem;
    background: white;
    border-top: 1px solid #ddd;
    font-size: 0.9rem;
    color:gainsboro;
  }
</style>
